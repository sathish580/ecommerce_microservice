Setting up instructions:

1. Download the folder and place them in the root folder of WAMP
2. Start WAMP and Docker
3. Open the folder in Visual Studio Code and navigate to the project folder
4. In the Terminal of VSC, ensure that it is pointing to the project folder and type docker-compose up --build
5. Once the containers have been set up, open Chrome and go to your localhost
6. Navigate to the project folder and you should be brought to an index.html page that shows a list of products.



Paypal Credentials
email: sb-nks5114456189@personal.example.com
password: XO4z;e{_